= Spa Lab Innovative Beauty Spa Wordpress Theme =

* by the DesignThemes team, http://themeforest.net/user/designthemes/